#ifndef COMPARE_H
#define COMPARE_H
#include "constants.h"
#include "compare.h"

int buff_cmp(char BUFFER1[], char BUFFER2[], char delim);
int str_cpy(char BUFFER[], char SRC[], char delim);

#endif