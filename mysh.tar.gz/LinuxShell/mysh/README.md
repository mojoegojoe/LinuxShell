# mysh
# Shell IO
  {cmd | arg |} &  - Command Runs in the Background. \
  {cmd | arg } | {cmd | arg} | ... - Connects procedually two or more processes. \
  {cmd | arg < } [V] { cmd | arg > } [V] ... - Allows for user defined redirected output : subset of redirection functionality to be extended. \
\