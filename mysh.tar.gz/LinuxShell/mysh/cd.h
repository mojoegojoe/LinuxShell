#ifndef CHANGE_DIRECTORY_H
#define CHANGE_DIRECTORY_H
#include "output.h"

int cd(char **args);

#endif