#ifndef COMMON_H
#define COMMON_H

#define BUFF_SIZE 256
#define COMMAND_SIZE 6
#define EXIT_FAILURE 1
#define HOME "/home/"
#define BUFFERSIZE 256
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>

#endif
