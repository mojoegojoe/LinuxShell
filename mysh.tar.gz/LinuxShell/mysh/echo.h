#ifndef ECHO_H
#define ECHO_H

#include "str_functions.h"

void echo(char **command);


#endif