#include "exit.h"

void exit_shell(int errorn) {
    exit(errorn);
}