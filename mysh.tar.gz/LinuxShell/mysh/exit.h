#ifndef EXIT_H
#define EXIT_H
#include <stdlib.h>
#define EXIT_FAILURE 1
#define EXIT_SUCCESS 0

void exit_shell(int errorn);

#endif 