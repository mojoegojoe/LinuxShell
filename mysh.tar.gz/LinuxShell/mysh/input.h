#ifndef INPUT_H
#define INPUT_H
#include "common.h"
int read_input(char *buffer, int buffer_size);

#endif