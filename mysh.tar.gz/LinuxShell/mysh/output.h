#ifndef OUTPUT_H
#define OUTPUT_H
#include "common.h"

int print_line(char *BUFFER, char *delim, int fd);

#endif