#ifndef PWD_H
#define PWD_H
#include "common.h"
#include "output.h"
#include "exit.h"
void pwd();
#endif
