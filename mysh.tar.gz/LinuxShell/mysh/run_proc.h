#ifndef RUN_PROC_H
#define RUN_PROC_H
#include "common.h"
#include "str_functions.h"
#include "built_in_handler.h"
#include "redirection.h"
#include "exit.h"
void runprocess(char **arg_buff, int isBackGround);

#endif 